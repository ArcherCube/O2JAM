#pragma once

#include "Path.h"
#include "Constant.h"
#include "Actor.h"


class Background : public Actor
{
public:
	explicit Background();

	virtual ~Background();
};

