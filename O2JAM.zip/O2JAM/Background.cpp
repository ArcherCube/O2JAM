#include "Background.h"


Background::Background() :Actor(BACKGROUND_PATH, BACKGROUND_POSITION, BACKGROUND_Z)
{
}

Background::~Background()
{
}